// live -8
// export const base_url="http://3.109.185.23:5500"


// live 199
export const base_url="http://65.0.203.146:5500"


//development
//  export const base_url="http://43.205.254.28:5500"

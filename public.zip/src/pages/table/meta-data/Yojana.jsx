import React, { useState, useMemo, useEffect } from "react";
import { advancedTable } from "../../../constant/table-data";
import Card from "@/components/ui/Card";
import Icon from "@/components/ui/Icon";
import Tooltip from "@/components/ui/Tooltip";
import {
    useTable,
    useRowSelect,
    useSortBy,
    useGlobalFilter,
    usePagination,
} from "react-table";
import GlobalFilter from "../react-tables/GlobalFilter";
import axios from "axios";
import { base_url } from "../../../config/base_url";
import Modal from "../../../components/ui/Modal";


const IndeterminateCheckbox = React.forwardRef(
    ({ indeterminate, ...rest }, ref) => {
        const defaultRef = React.useRef();
        const resolvedRef = ref || defaultRef;

        React.useEffect(() => {
            resolvedRef.current.indeterminate = indeterminate;
        }, [resolvedRef, indeterminate]);

        return (
            <input
                type="checkbox"
                ref={resolvedRef}
                {...rest}
                className="table-checkbox"
            />
        );
    }
);

const Yojana = ({ title = "Caste" }) => {

    const COLUMNS = [
        {
            Header: "Sr No",
            accessor: "srNo",
            Cell: ({ row }) => {
                return <span>{row.index + 1}</span>;
            },
        },
        {
            Header: "Id",
            accessor: "_id",
            Cell: (row) => {
                return <span>{row?.cell?.value}</span>;
            },
        },
        {
            Header: "Name",
            accessor: "castname",
            Cell: (row) => {
                return <span>{row?.cell?.value}</span>;
            },
        },
        {
            Header: "Action",
            accessor: "action",
            Cell: (row) => {
                return (
                    <div className="flex space-x-3 rtl:space-x-reverse">
                        <Tooltip content="Edit" placement="top" arrow animation="shift-away">
                            <button className="action-btn" type="button" onClick={() => setEditCasteModal(true)}>
                                <Icon icon="heroicons:pencil-square" />
                            </button>
                        </Tooltip>
                        <Tooltip
                            content="Delete"
                            placement="top"
                            arrow
                            animation="shift-away"
                            theme="danger"
                        >
                            <button className="action-btn" type="button" >
                                <Icon icon="heroicons:trash" />
                            </button>
                        </Tooltip>
                    </div>
                );
            },
        },
    ];
    const columns = useMemo(() => COLUMNS, []);
    const [casteMeta, setCasteMeta] = useState([]);
    const data = useMemo(() => casteMeta, [casteMeta]);
    const [editCasteModal, setEditCasteModal] = useState(false)
    const [deleteModal, setDeleteModal] = useState(false)
    const [addCasteModal, stAddCastModal] = useState(false)
    const tableInstance = useTable(
        {
            columns,
            data,
        },
        useGlobalFilter,
        useSortBy,
        usePagination,
        useRowSelect
    );

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        page,
        nextPage,
        previousPage,
        canNextPage,
        canPreviousPage,
        pageOptions,
        state,
        gotoPage,
        pageCount,
        setPageSize,
        setGlobalFilter,
        prepareRow,
    } = tableInstance;

    const { globalFilter, pageIndex, pageSize } = state;

    const getCaste = () => {
        axios
            .get(`${base_url}/getCastMeta`)
            .then((resp) => {
                setCasteMeta(resp.data.data);
            })
            .catch((error) => {
                console.log(error);
            });
    };

    useEffect(() => {
        getCaste();
    }, []);

    return (
        <Card>
            <h4 className="card-title">{title}</h4>
            <div className="md:flex justify-end gap-4 items-center mb-6">
                <div>
                    <GlobalFilter filter={globalFilter} setFilter={setGlobalFilter} />
                </div>
                <div>
                    <button className="bg-[#b91c1c] text-white px-5 h-10 rounded-md " onClick={()=>stAddCastModal(true)}>
                        Add New Caste
                    </button>
                </div>
                {/* Add cast modal */}
                <Modal
                    title="Add Caste"
                    activeModal={addCasteModal}
                    className="max-w-xl"
                    themeClass="bg-blue-500 blue:bg-blue-500 blue:border-b blue:border-blue-700"
                    onClose={() => stAddCastModal(false)}
                >
                    hi
                </Modal>

            </div>
            <div className="overflow-x-auto -mx-6">
                <div className="inline-block min-w-full align-middle">
                    <div className="overflow-hidden">
                        <table
                            className="min-w-full divide-y divide-slate-100 table-fixed dark:divide-slate-700"
                            {...getTableProps()}
                        >
                            <thead className="bg-slate-200 dark:bg-slate-700">
                                {headerGroups.map((headerGroup) => (
                                    <tr {...headerGroup.getHeaderGroupProps()}>
                                        {headerGroup.headers.map((column) => (
                                            <th
                                                {...column.getHeaderProps(column.getSortByToggleProps())}
                                                scope="col"
                                                className="table-th"
                                            >
                                                {column.render("Header")}
                                                <span>
                                                    {column.isSorted
                                                        ? column.isSortedDesc
                                                            ? " 🔽"
                                                            : " 🔼"
                                                        : ""}
                                                </span>
                                            </th>
                                        ))}
                                    </tr>
                                ))}
                            </thead>
                            <tbody
                                className="bg-white divide-y divide-slate-100 dark:bg-slate-800 dark:divide-slate-700"
                                {...getTableBodyProps()}
                            >
                                {page.map((row) => {
                                    prepareRow(row);
                                    return (
                                        <tr {...row.getRowProps()}>
                                            {row.cells.map((cell) => {
                                                return (
                                                    <td {...cell.getCellProps()} className="table-td">
                                                        {cell.render("Cell")}
                                                    </td>
                                                );
                                            })}
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div className="md:flex justify-between items-center mt-6">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <select
                        className="form-control py-2 w-max"
                        value={pageSize}
                        onChange={(e) => setPageSize(Number(e.target.value))}
                    >
                        {[10, 25, 50].map((pageSize) => (
                            <option key={pageSize} value={pageSize}>
                                Show {pageSize}
                            </option>
                        ))}
                    </select>
                    <span className="text-sm font-medium text-slate-600 dark:text-slate-300">
                        Page {pageIndex + 1} of {pageOptions.length}
                    </span>
                </div>
                <ul className="flex items-center space-x-3 rtl:space-x-reverse">
                    <li>
                        <button
                            className={`${!canPreviousPage ? "opacity-50 cursor-not-allowed" : ""
                                }`}
                            onClick={() => gotoPage(0)}
                            disabled={!canPreviousPage}
                        >
                            <Icon icon="heroicons:chevron-double-left-solid" />
                        </button>
                    </li>
                    <li>
                        <button
                            className={`${!canPreviousPage ? "opacity-50 cursor-not-allowed" : ""
                                }`}
                            onClick={previousPage}
                            disabled={!canPreviousPage}
                        >
                            Prev
                        </button>
                    </li>
                    {pageOptions.map((_, pageIdx) => (
                        <li key={pageIdx}>
                            <button
                                className={`${pageIdx === pageIndex
                                        ? "bg-slate-900 text-white"
                                        : "bg-slate-100 text-slate-900"
                                    } text-sm rounded h-6 w-6`}
                                onClick={() => gotoPage(pageIdx)}
                            >
                                {pageIdx + 1}
                            </button>
                        </li>
                    ))}
                    <li>
                        <button
                            className={`${!canNextPage ? "opacity-50 cursor-not-allowed" : ""
                                }`}
                            onClick={nextPage}
                            disabled={!canNextPage}
                        >
                            Next
                        </button>
                    </li>
                    <li>
                        <button
                            onClick={() => gotoPage(pageCount - 1)}
                            disabled={!canNextPage}
                            className={`${!canNextPage ? "opacity-50 cursor-not-allowed" : ""
                                }`}
                        >
                            <Icon icon="heroicons:chevron-double-right-solid" />
                        </button>
                    </li>
                </ul>
            </div>
            <Modal
                title="Edit Caste"
                activeModal={editCasteModal}
                className="max-w-xl"
                themeClass="bg-blue-500 blue:bg-blue-500 blue:border-b blue:border-blue-700"
                onClose={() => setEditCasteModal(false)}
            >

            </Modal>


        </Card>
    );
};

export default Yojana;
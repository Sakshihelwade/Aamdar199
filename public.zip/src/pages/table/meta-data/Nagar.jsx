import React from 'react'

const Nagar = () => {
  return (
    <div>
      
    </div>
  )
}

export default Nagar

import React from 'react'

const Society = () => {
  return (
    <div>
      
    </div>
  )
}

export default Society

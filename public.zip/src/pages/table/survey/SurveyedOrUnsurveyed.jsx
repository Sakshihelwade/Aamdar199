import React from 'react'

const SurveyedOrUnsurveyed = () => {
  return (
    <div>
      
    </div>
  )
}

export default SurveyedOrUnsurveyed

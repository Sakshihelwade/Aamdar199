import React from 'react'

const NewVoters = () => {
  return (
    <div>
      
    </div>
  )
}

export default NewVoters
